# Changelog

## 1.2.0

- Update to wyoming-satellite 1.2.0

## 1.0.0

- Initial release

